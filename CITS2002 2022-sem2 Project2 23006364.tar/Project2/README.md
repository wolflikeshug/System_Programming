# Trove Program

## If you are marking this project, Please read both README files from v1.0 and v2.0, the Notice sections in the two README files are different.

## v 2.0

- Introduced multi-threads to boost the speed of the Build / Update Function of the program 
  - (save about 50% time, works especially well with a large number of files, depends on the machine you are running)
  - (Warning: This version has Potential FLAWS. Please read the README.md instruction of v2.0 to get more info. if this program frequently crashes on the test machine, For stability reasons, I suggest using v1.0 for the automation test.)

- improve the reading speed of trove-file, this will speed up the program overall ( a little bit :) )
- introducing access() to check the file's state.
- enlarge the hashtable size to suit greater number of files and words.

## v 1.0

- Implement the basic functions that are listed in [Project Instruction](https://teaching.csse.uwa.edu.au/units/CITS2002/projects/project2.php)
- ADD -v function to print out debug info

