//  CITS2002 Project 2 2022
//  Student:   23006364   HU   ZHUO   100

#ifndef _WORDFILEIO_H
#define _WORDFILEIO_H

#include "datastruct/hashtable_mlist.h"

// RECORD ALL THE WORDS FROM FILE INTO THE HASHTABLE
extern void recordWord(char *filename, HASHTABLE_MLIST *hashtable);

#endif