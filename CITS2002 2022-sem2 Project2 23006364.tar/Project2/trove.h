//  CITS2002 Project 2 2022
//  Student:   23006364   HU   ZHUO   100

#ifndef _TROVE_H
#define _TROVE_H

#include "fileIO/wordFileIO.h"
#include "fileIO/trovefileIO.h"

#endif