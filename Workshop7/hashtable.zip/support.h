
//  THESE FUNCTIONS ARE DECLARED HERE, AND DEFINED IN support.c :

extern	void	reset_words(void);
extern	char	*next_word(void);
extern	long	microseconds(void);
