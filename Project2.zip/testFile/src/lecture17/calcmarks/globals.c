#include  "calcmarks.h"              // we use double-quotes

double    projmarks[ MAXMARKS ];     // array's size is defined
double    exammarks[ MAXMARKS ];     // array's size is defined

bool      verbose = false;           // global is initialized
